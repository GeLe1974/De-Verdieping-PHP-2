<?php
/**
 * Created by PhpStorm.
 * User: Geert
 * Date: 04/10/16
 * Time: 21:11
 */



echo"<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <title>PDF</title>
    <!-- Latest compiled and minified CSS & JS -->
<link rel=\"stylesheet\" media=\"screen\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\">
<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js\"></script>
<link rel='stylesheet' href='font-awesome/css/font-awesome.css'>

</head>
<body>
<div class='jumbotron'>
	<div class='container'>
		<h1>PDF</h1>
		<p>Oefeningen om PDF's te genereren</p>
		<ul class='list-inline'>
		    <li><a href='eerstePDF.php' class=\"btn btn-success btn-lg\">eerste PDF <i class=\"fa fa-print\"></i></a></li>
		    <li><a href='HeaderFooter.php' class=\"btn btn-success btn-lg\">PDF met header & footer <i class=\"fa fa-print\"></i></a></li>
		    <li><a href='db-pdf.php' class=\"btn btn-success btn-lg\">PDF met data uit database <i class=\"fa fa-print\"></i></a></li>

        </ul>

		</p>
	</div>
</div>";





echo"

</body>
</html>

";