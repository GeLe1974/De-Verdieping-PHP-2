<?php
session_start();

include_once 'classes/DB.php';
include_once 'classes/Quote.php';
