<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Quotes</title>

  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="css/styles.css"/>
  <script src="ckeditor/ckeditor.js"></script>
</head>
<body>

<div class="container">
  <div class="row header">
    <div class="col-md-12">
      <h1 class="pull-left">Quotes</h1>
<!--      <a href="quote-toevoegen.php" class="btn btn-info pull-right">Quote toevoegen</a>-->
    </div>
  </div>

